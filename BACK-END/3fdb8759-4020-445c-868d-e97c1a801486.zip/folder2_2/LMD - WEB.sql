
/*   Tabla Usuario    
insert into Usuario(u_id_usuario,u_nombre,u_correo,u_telefono,u_tipo_usuario,u_contrasena,u_direcion,u_eliminar) 
values (1,"Jessica Hernandez Flores","jessflores@gmail.com",2261653150,'cliente',"jhf12flores", "Calle Mexico #13, Veracruz, Veracruz",false);

insert into Usuario(u_id_usuario,u_nombre,u_correo,u_telefono,u_tipo_usuario,u_contrasena,u_direcion,u_eliminar) 
values (2,"Oscar Fernandez Mendez","oscar1290@gmail.com",2290459270,'cliente',"oscar90mendez", "Calle Durango #28, Veracruz, Veracruz",false);

insert into Usuario(u_id_usuario,u_nombre,u_correo,u_telefono,u_tipo_usuario,u_contrasena,u_direcion,u_eliminar) 
values (3,"Alejandra Mendez Ramirez","alerami95@gmail.com",2294784230,'cliente',"alejandramen", "Calle Nuevo Mexico #65 Monterrey Nuevo Leon",false);

insert into Usuario(u_id_usuario,u_nombre,u_correo,u_telefono,u_tipo_usuario,u_contrasena,u_direcion,u_eliminar) 
values (4,"David Salazar Barrios","salazar2020@gmail.com",2296824034,'cliente',"davidbar22sal", "Calle Veracruz #32 Xalapa Veracruz",false);

insert into Usuario(u_id_usuario,u_nombre,u_correo,u_telefono,u_tipo_usuario,u_contrasena,u_direcion,u_eliminar) 
values (5,"Vicente Vasquez Reyes","vasquezVR@gmail.com",2285644620,'cliente',"reyvicente18", "Calle Nuevo Leon #45, Tijuana, Baja California",false);

insert into Usuario(u_id_usuario,u_nombre,u_correo,u_telefono,u_tipo_usuario,u_contrasena,u_direcion,u_eliminar) 
values (6,"Maria Galindo Alarcon","galindo20@gmail.com",2298756418,'admin',"mariagalindo", "Calle Durango #12, Tampico, Tamaulipas",false);

insert into Usuario(u_id_usuario,u_nombre,u_correo,u_telefono,u_tipo_usuario,u_contrasena,u_direcion,u_eliminar) 
values (7,"Israel Jimenez Morales","isramora@gmail.com",2298756418,'admin',"jiemenez30", "Calle Nuevo Mexico. #35, Ciudad Juarez, Chihuahua",false);

insert into Usuario(u_id_usuario,u_nombre,u_correo,u_telefono,u_tipo_usuario,u_contrasena,u_direcion,u_eliminar) 
values (8,"Alejandra Rivera Perez","rivera89@gmail.com",2291542120,'admin',"riveraperez25", "Calle Oaxaca. #2, Ciudad de Mexico, Edo Mexico",false);

insert into Usuario(u_id_usuario,u_nombre,u_correo,u_telefono,u_tipo_usuario,u_contrasena,u_direcion,u_eliminar) 
values (9,"Bernardo Lopez Ruiz","bernardoruiz35@gmail.com",2295213550,'admin',"berna2109", "Calle Puebla #7, Veracruz, Veracruz",false);

insert into Usuario(u_id_usuario,u_nombre,u_correo,u_telefono,u_tipo_usuario,u_contrasena,u_direcion,u_eliminar) 
values (10,"Sofia Perez Carrera","perez80@gmail.com",2297483125,'admin',"alejandramen", "Calle Queretaro. #5 Ciudad de Mexico, Edo Mexico ",false);

*/

/*   Tabla Libro    */
insert into Libro(l_id_libro,l_nombre,l_cantidad,l_precio,l_autor,l_fecha_pub,l_genero,l_tipo, l_descripcion, l_eliminado) 
values (1,"Don Quijote de la mancha",50,200.00,"Miguel de Cervantes",'1995-10-05','Drama','Libro',
"El ingenioso hidalgo don Quijote de la Mancha narra las aventuras de Alonso Quijano, un hidalgo pobre que de tanto leer novelas de 
caballería acaba enloqueciendo y creyendo ser un caballero andante, nombrándose a sí mismo como don Quijote de la Mancha.",0);

insert into Libro(l_id_libro,l_nombre,l_cantidad,l_precio,l_autor,l_fecha_pub,l_genero,l_tipo, l_descripcion, l_eliminado) 
values (2,"En busca del tiempo perdido",150,150.00,"Marcel Proust",'1999-12-25','Misterio','Libro',
"En busca del tiempo perdido narra la vida tal como la experimenta cada persona desde su cuerpo y su espiritualidad únicas. 
Se desenvuelve, por tanto, en el ámbito de las emociones, de lo subjetivo y lo irracional.",0);

insert into Libro(l_id_libro,l_nombre,l_cantidad,l_precio,l_autor,l_fecha_pub,l_genero,l_tipo, l_descripcion, l_eliminado) 
values (3,"MOBY DICK",60,500.00,"Herman Melville",'2006-01-19','Ciencia Ficcion','Libro',
"El capitán del Pequod, un barco ballenero, vive obsesionado por dar caza a Moby Dick, la gran ballena blanca que le arrancó una pierna 
y lo llenó de odio y sed de venganza.",0);

insert into Libro(l_id_libro,l_nombre,l_cantidad,l_precio,l_autor,l_fecha_pub,l_genero,l_tipo, l_descripcion, l_eliminado) 
values (4,"Guerra y paz",70,400.00,"León Tolstói",'1987-05-10','Ciencia Ficcion','Libro',
"Obra monumental, que incluye a más de quinientos personajes históricos y de ficción, Guerra y paz alterna en su magnífica trama historias 
familiares con las vicisitudes del ejército napoleónico",0);

insert into Libro(l_id_libro,l_nombre,l_cantidad,l_precio,l_autor,l_fecha_pub,l_genero,l_tipo, l_descripcion, l_eliminado) 
values (5,"Cuentos",50,80.00,"Antón Chéjov",'1978-08-06','Drama','Libro',
"Sus temas son los grandes conflictos que invaden su alma. Su ansia de amor y justicia, que tanto sufrimiento le produciría a lo largo de su vida, 
lo llevará por un contradictorio sendero en busca de la ansiada perfección moral, predicando en sus obras el bien y la justicia.",0);

insert into Libro(l_id_libro,l_nombre,l_cantidad,l_precio,l_autor,l_fecha_pub,l_genero,l_tipo, l_descripcion, l_eliminado) 
values (6,"Crimen y castigo",80,300.00,"Fiódor Dostoievski",'1195-05-04','Drama','Libro',
"Considerada por la crítica como la primera obra maestra de Dostoievski, Crimen y castigo es un profundo análisis psicológico de su protagonista, 
el joven estudiante Raskólnikov, cuya firme creencia en que los fines humanitarios justifican la maldad le conduce al asesinato de una usurera.",0);

insert into Libro(l_id_libro,l_nombre,l_cantidad,l_precio,l_autor,l_fecha_pub,l_genero,l_tipo, l_descripcion, l_eliminado) 
values (7,"Peter Pan",50,200.00,"James Matthew Barrie",'1975-09-26','Fantasia','Libro',
"La novela “Peter Pan” cuenta la historia de tres niños, Wendy, Michael y John, que se adentran en la tierra de “Nunca Jamás” al lado de Peter, 
un niño eterno que decidió nunca crecer para vivir por siempre en un mundo de aventuras, batallas de barcos y piratas",0);

insert into Libro(l_id_libro,l_nombre,l_cantidad,l_precio,l_autor,l_fecha_pub,l_genero,l_tipo, l_descripcion, l_eliminado) 
values (8,"El corazon de las tinieblas",50,400.00,"Joseph Conrad",'1999-12-10','Ciencia Ficcion','Libro',
"Joseph Conrad escribió esta novela basada en su experiencia en el Congo. Este clásico habla de la lucha del hombre contra los elementos naturales, 
si bien ha servido y sirve para criticar la amarga historia de un pueblo sometido a los excesos y privilegios de la colonización.",0);

insert into Libro(l_id_libro,l_nombre,l_cantidad,l_precio,l_autor,l_fecha_pub,l_genero,l_tipo, l_descripcion, l_eliminado) 
values (9,"Orgullo y prejuicio",50,200.00,"Jane Austen",'1995-02-14','Ciencia Ficcion','Libro',
"Orgullo y prejuicio narra las aventuras y desventuras amorosas de las hermanas Bennet, centrándose en el personaje de Elizabeth, a través de las cuales 
la autora nos presenta con comicidad la sociedad de su tiempo y coloca a la mujer",0);

insert into Libro(l_id_libro,l_nombre,l_cantidad,l_precio,l_autor,l_fecha_pub,l_genero,l_tipo, l_descripcion, l_eliminado) 
values (10,"Metamorfosis",90,150.00,"J Ovidio",'1813-01-28','Fantasia','Libro',
"La metamorfosis es una novela de Franz Kafka, publicada en 1915. Cuenta la historia de la transformación de Gregorio Samsa en un monstruoso insecto,
 y del drama familiar que se desata a raíz de este acontecimiento.",0);
 
insert into Libro(l_id_libro,l_nombre,l_cantidad,l_precio,l_autor,l_fecha_pub,l_genero,l_tipo, l_descripcion, l_eliminado) 
values (11,"m m",90,150.00,"J Ovidio",'1813-01-28','Fantasia','Libro',
"La metamorfosis es una novela de Franz Kafka, publicada en 1915. Cuenta la historia de la transformación de Gregorio Samsa en un monstruoso insecto,
 y del drama familiar que se desata a raíz de este acontecimiento.",0);

/*   Tabla compra    */
insert into Compra(c_id_compra,c_precio_total,c_id_admin,c_fecha,c_eliminar) 
values (1,5000.00,6,'2023-02-10',0);

insert into Compra(c_id_compra,c_precio_total,c_id_admin,c_fecha,c_eliminar) 
values (2,2000.00,7,'2023-02-10',0);

insert into Compra(c_id_compra,c_precio_total,c_id_admin,c_fecha,c_eliminar) 
values (3,1500.00,8,'2023-02-10',0);

insert into Compra(c_id_compra,c_precio_total,c_id_admin,c_fecha,c_eliminar) 
values (4,5000.00,6,'2023-02-10',0);

insert into Compra(c_id_compra,c_precio_total,c_id_admin,c_fecha,c_eliminar) 
values (5,2000.00,10,'2023-02-10',0);

/*   Tabla compra    */
insert into Detalle_Compra(dc_id_detcom,dc_id_compra,dc_id_libro,dc_subtotal,dc_pzs_compra,dc_eliminar) 
values (1,1,3,5000.00,10,0);

insert into Detalle_Compra(dc_id_detcom,dc_id_compra,dc_id_libro,dc_subtotal,dc_pzs_compra,dc_eliminar) 
values (2,2,2,2000.00,20,0);

insert into Detalle_Compra(dc_id_detcom,dc_id_compra,dc_id_libro,dc_subtotal,dc_pzs_compra,dc_eliminar) 
values (3,3,10,1500.00,10,0);

insert into Detalle_Compra(dc_id_detcom,dc_id_compra,dc_id_libro,dc_subtotal,dc_pzs_compra,dc_eliminar) 
values (4,4,7,5000.00,15,0);

insert into Detalle_Compra(dc_id_detcom,dc_id_compra,dc_id_libro,dc_subtotal,dc_pzs_compra,dc_eliminar) 
values (5,5,9,2000.00,10,0);


/*   Tabla venta    */
insert into Venta(v_id_venta,v_id_cliente,v_monto_total,v_fecha_venta,v_eliminado) 
values (1,1,500.00,'2023-02-15',0);

insert into Venta(v_id_venta,v_id_cliente,v_monto_total,v_fecha_venta,v_eliminado) 
values (2,5,200.00,'2023-02-16',0);

insert into Venta(v_id_venta,v_id_cliente,v_monto_total,v_fecha_venta,v_eliminado) 
values (3,2,150.00,'2023-02-17',0);

insert into Venta(v_id_venta,v_id_cliente,v_monto_total,v_fecha_venta,v_eliminado) 
values (4,3,150.00,'2023-02-18',0);

insert into Venta(v_id_venta,v_id_cliente,v_monto_total,v_fecha_venta,v_eliminado) 
values (5,4,80.00,'2023-02-19',0);

/*   Tabla venta    */
insert into Detalle_Venta(dv_id_detvent,dv_id_vent,dv_id_libro,dv_subtotal,dv_pzs_venta,dv_eliminado) 
values (1,1,3,500.00,1,0);

insert into Detalle_Venta(dv_id_detvent,dv_id_vent,dv_id_libro,dv_subtotal,dv_pzs_venta,dv_eliminado) 
values (2,2,1,200.00,1,0);

insert into Detalle_Venta(dv_id_detvent,dv_id_vent,dv_id_libro,dv_subtotal,dv_pzs_venta,dv_eliminado) 
values (3,3,10,150.00,1,0);

insert into Detalle_Venta(dv_id_detvent,dv_id_vent,dv_id_libro,dv_subtotal,dv_pzs_venta,dv_eliminado) 
values (4,4,2,150.00,1,0);

insert into Detalle_Venta(dv_id_detvent,dv_id_vent,dv_id_libro,dv_subtotal,dv_pzs_venta,dv_eliminado) 
values (5,5,5,80.00,1,0);



/*   Tabla Reseña    */


Insert into Resenia(r_id_resena, r_id_cliente, r_id_libro, r_res_cli, r_fecha, r_eliminado)
values(1,1,5,'El libro esta incompleto me gustaría que tuviera el desarrollo de personaje','2023-02-23',false);

Insert into Resenia(r_id_resena, r_id_cliente, r_id_libro, r_res_cli, r_fecha, r_eliminado)
values(2,3,3,"Nos muestra la capacidad que tiene las personas de encajar en los fuertes momentos",'2023-02-23', false);

Insert into Resenia(r_id_resena, r_id_cliente, r_id_libro, r_res_cli, r_fecha, r_eliminado)
values(3,2,4,"Se va haciendo más chico hasta desaparecer en los últimos párrafos",'2023-02-23', false);

Insert into Resenia(r_id_resena, r_id_cliente, r_id_libro, r_res_cli, r_fecha, r_eliminado)
values(4,5,1,"Emocionante libro muy ilustrado, que cuenta una historia llena de ilusión y fantasías protagonizada",'2023-02-23', false);

Insert into Resenia(r_id_resena, r_id_cliente, r_id_libro, r_res_cli, r_fecha, r_eliminado)
values(5,5,1,"Muchos la considera como un Biblia de emociones, un camino sentimental que logramos seguir sujetando una emo
ción con otra, comenzando por la ternura y llegando al amor",'2023-02-23', false);

/*   Tabla Favoritos    */
Insert into Favorito(f_id_favorito, f_id_cliente,   f_id_libro,   f_eliminar)
values(1,1,1,0);

Insert into Favorito(f_id_favorito, f_id_cliente,   f_id_libro,   f_eliminar)
values(2,2,5,0);

Insert into Favorito(f_id_favorito, f_id_cliente,   f_id_libro,   f_eliminar)
values(3,3,4,0);

Insert into Favorito(f_id_favorito, f_id_cliente,   f_id_libro,   f_eliminar)
values(4,5,3,0);

Insert into Favorito(f_id_favorito, f_id_cliente,   f_id_libro,   f_eliminar)
values(5,4,2,0);

/*  
Errores que me encontré
En u_direccion hay que agregar comas y puntos
En todos los precios, añadir mas digitos al float
En el nombre de libro no admite cadenas de un caracter como guerra y paz
El r_eliminar me dio error , no sé porque
*/


